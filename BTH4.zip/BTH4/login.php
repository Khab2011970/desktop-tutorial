<!DOCTYPE HTML> 
<html>   
<body> 
 
<form action="log.php" method="post"> 
Username: <input type="text" name="email" value="' OR '1'='1"><br> 
Password: <input type="password" name="pass"><br> 
 
<input type="submit"> 
</form> 
 
</body> 
</html>
